'use strict';

import React, { Component } from 'react';
import { Switch, NavBar, Checkbox, Radio, Input, Tabs, TabBar, Badge } from 'antd-mobile';

import styles from './assets/index.module.css';

const print = function (value) {};
class DDS_lanhupage_0 extends Component {
  state = {};
  setValue(val) {}
  render() {
    return (
      <div className={`${styles.page} flex-col`}>
        <div className={`${styles['box_1']} flex-row`}>
          <div className={`${styles['section_1']} flex-col`}>
            <div className={`${styles['group_1']} flex-row`}>
              <span className={`${styles['text_1']}`}>9:28</span>
              <img
                className={`${styles['thumbnail_1']}`}
                src={
                  require('./assets/img/SketchPng360cf53083fb4b7bdea1e78734ed0046dca74d03826eaf3e4459ecbbbcbb934b.png')
                }
              />
              <img
                className={`${styles['thumbnail_2']}`}
                src={
                  require('./assets/img/SketchPng235df50f2b085e0bf6a1a7e49c9ea1a58d746459a3f2f1698b7785dd734e9548.png')
                }
              />
              <img
                className={`${styles['image_1']}`}
                src={
                  require('./assets/img/SketchPngf8248615de614e6e2a296b516cfef4b2041fdfaf781ae90a7beb64e4ce57bf26.png')
                }
              />
            </div>
            <div className={`${styles['image-wrapper_1']} flex-row`}>
              <img
                className={`${styles['label_1']}`}
                src={
                  require('./assets/img/1a75d4af7a3c4940b3663d81272d2f20_mergeImage.png')
                }
              />
            </div>
            <div className={`${styles['text-wrapper_1']} flex-row`}>
              <span className={`${styles['text_2']}`}>登录</span>
            </div>
            <div className={`${styles['group_2']} flex-row`}>
              <div className={`${styles['box_2']} flex-row justify-between`}>
                <img
                  className={`${styles['label_2']}`}
                  src={
                    require('./assets/img/SketchPng1a10c20eafcd764d76fa8f10da58f8799b36f13dd62fbe237a60ae103980858c.png')
                  }
                />
                <span className={`${styles['text_3']}`}>请输入您的邮箱账号</span>
                <div className={`${styles['section_2']} flex-row justify-between`}>
                  <img
                    className={`${styles['label_3']}`}
                    src={
                      require('./assets/img/SketchPng1a10c20eafcd764d76fa8f10da58f8799b36f13dd62fbe237a60ae103980858c.png')
                    }
                  />
                  <div className={`${styles['image-text_1']} flex-row justify-between`}>
                    <span className={`${styles['text-group_1']}`}>1243222222124322222</span>
                    <img
                      className={`${styles['label_4']}`}
                      src={
                        require('./assets/img/SketchPng757c641c47da43cad990948c8f352852188f4b43b542cfc5496062fe733483a7.png')
                      }
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={`${styles['text-wrapper_2']} flex-row`}>
              <span className={`${styles['text_4']}`}>请输入正确的邮箱格式</span>
            </div>
            <div className={`${styles['group_3']} flex-row`}>
              <div className={`${styles['group_4']} flex-row`}>
                <div className={`${styles['image-text_2']} flex-row justify-between`}>
                  <img
                    className={`${styles['label_5']}`}
                    src={
                      require('./assets/img/SketchPng4d13fd308481531fc141fb4256149d3acfc774600734363b59db40979e36151f.png')
                    }
                  />
                  <span className={`${styles['text-group_2']}`}>*******************</span>
                </div>
              </div>
            </div>
            <div className={`${styles['text-wrapper_3']} flex-row`}>
              <span className={`${styles['text_5']}`}>8-12个字符，包括数字和英文</span>
            </div>
            <div className={`${styles['group_5']} flex-row`}>
              <div className={`${styles['image-text_3']} flex-row justify-between`}>
                <img
                  className={`${styles['thumbnail_3']}`}
                  src={
                    require('./assets/img/SketchPng4b19373a8d47de67eaa30abef7bbb27500ebd3b466311cd0967743023982080b.png')
                  }
                />
                <div className={`${styles['text-group_3']}`}>
                  <span className={`${styles['text_6']}`}>阅读并同意</span>
                  <span className={`${styles['text_7']}`}>隐私政策</span>
                  <span className={`${styles['text_8']}`}>&nbsp;与</span>
                  <span className={`${styles['text_9']}`}>用户协议</span>
                </div>
              </div>
            </div>
            <div className={`${styles['group_6']} flex-row`}>
              <div className={`${styles['text-wrapper_4']} flex-col`}>
                <span className={`${styles['text_10']}`}>登录</span>
              </div>
            </div>
            <div className={`${styles['text-wrapper_5']} flex-row`}>
              <span className={`${styles['text_11']}`}>忘记密码</span>
            </div>
          </div>
          <img
            className={`${styles['image_2']}`}
            src={
              require('./assets/img/SketchPngdb52b001b113a4472d2153a7a83c24574aff8e4b4a27f1bbefad18fe2043e1c0.png')
            }
          />
        </div>
      </div>
    );
  }
}
export default DDS_lanhupage_0;
